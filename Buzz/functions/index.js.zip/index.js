const {onDocumentCreated} = require("firebase-functions/v2/firestore");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const {getMessaging} = require("firebase-admin/messaging");
const logger = require("firebase-functions/logger");

// Initialize Firebase Admin SDK
initializeApp();

const db = getFirestore();

exports.sendRequestNotification = onDocumentCreated("gameRequests/{requestId}",
    async (event) => {
      const doc = event.data;

      if (!doc) {
        logger.error("No document snapshot available.");
        return;
      }

      const data = doc.data();
      const senderName = data.senderName || "Someone";
      const receiverId = data.opponentId;

      if (!receiverId) {
        logger.error("receiverId is missing in the document.");
        return;
      }

      try {
        // Get FCM token of the receiver
        const userDoc = await db.collection("users").doc(receiverId).get();
        const userData = userDoc.data();

        if (!userDoc.exists || !userData.fcmToken) {
          logger.warn(`No FCM token found for user ${receiverId}`);
          return;
        }

        const fcmToken = userData.fcmToken;

        // Notification payload
        const message = {
          token: fcmToken,
          notification: {
            title: "New Request",
            body: `${senderName} has sent you a request.`,
          },
          data: {
            senderId: data.senderId || "",
            requestId: event.params.requestId,
          },
        };

        // Send push notification
        await getMessaging().send(message);

        logger.info(`Notification sent to user ${receiverId}`);
      } catch (error) {
        logger.error("Error sending notification:", error);
      }
    });
